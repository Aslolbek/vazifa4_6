const auth = require("./auth.route");
const todo = require("./todo.route");

module.exports = [auth, todo];
